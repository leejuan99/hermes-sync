# WhatsApp Gateway Setup (Baileys) — VPS Quick Reference

Complete setup flow for running Hermes WhatsApp gateway on a headless VPS (Ubuntu 22.04, aaPanel, GreenCloud Singapore).

---

## Prerequisites

- VPS with SSH key-only auth (port 2222, GreenCloud external firewall)
- Root access via SSH key (`~/.ssh/vps_key` in this environment)
- Domain/subdomain pointed to VPS (for webhook URL if needed)

---

## 1. Install Hermes on VPS

```bash
ssh -i ~/.ssh/vps_key -p 2222 root@194.127.192.52 \
  "curl -fsSL https://hermes-agent.nousresearch.com/install.sh | bash"
```

Installs to `/usr/local/lib/hermes-agent`, command at `/usr/local/bin/hermes`, data at `/root/.hermes/`.

---

## 2. Configure Gateway + WhatsApp (Baileys)

```bash
ssh -i ~/.ssh/vps_key -p 2222 root@194.127.192.52 "hermes gateway setup"
```

Interactive wizard:
- Select **26** (WhatsApp)
- Enable → `Y`
- Allowed users → `*` (anyone) or comma-separated phone numbers
- Home chat ID → leave empty
- Done → **27**
- Start gateway now → `Y`
- Install as service → `Y`
- Choose **1** (User service, linger enabled)

---

## 3. Pair WhatsApp (Interactive — Requires TTY)

**Cannot run via piped stdin.** Must use `tmux` with allocated PTY:

```bash
# On VPS, start pairing in tmux session
ssh -i ~/.ssh/vps_key -p 2222 root@194.127.192.52 -t \
  "tmux new-session -d -s whatsapp_pair 'hermes whatsapp'"

# Send choices
ssh -i ~/.ssh/vps_key -p 2222 root@194.127.192.52 \
  "tmux send-keys -t whatsapp_pair '1' Enter"   # Mode: separate bot number

ssh -i ~/.ssh/vps_key -p 2222 root@194.127.192.52 \
  "tmux send-keys -t whatsapp_pair '*' Enter"   # Allow all users

# Watch QR code (refreshes every few seconds)
ssh -i ~/.ssh/vps_key -p 2222 root@194.127.192.52 \
  "tmux capture-pane -t whatsapp_pair -p"
```

### On Phone (WhatsApp):
1. Open WhatsApp → **3 dots** → **Linked devices** → **Link a device**
2. Scan QR code displayed in terminal
3. Terminal shows "Connected!" / "Paired!" → gateway auto-restarts

---

## 4. Verify Gateway Running

```bash
ssh -i ~/.ssh/vps_key -p 2222 root@194.127.192.52 "hermes gateway status"
```

Expected:
```
● hermes-gateway.service - Hermes Agent Gateway
     Active: active (running) since ...
     ...
✓ whatsapp: Paired and connected
```

---

## 5. Test Message

Send a WhatsApp message to the bot number → Hermes replies in chat.

---

## Troubleshooting

| Issue | Fix |
|-------|-----|
| `hermes whatsapp` says "requires interactive terminal" | Use `tmux` as shown above |
| QR code not scanning / too small | Zoom terminal (Ctrl++), or run `hermes whatsapp` locally then copy session |
| Gateway stuck "activating (auto-restart)" | WhatsApp not paired yet — complete pairing |
| Service dies on logout | `loginctl enable-linger root` (already done by installer) |
| `permission denied` on SSH | Use correct key: `~/.ssh/vps_key` not `id_ed25519` |
| Port 22 blocked | GreenCloud firewall → add rule for port 2222 in panel |

---

## Key Paths on VPS

| Path | Purpose |
|------|---------|
| `/usr/local/bin/hermes` | Main command |
| `/root/.hermes/config.yaml` | Gateway + platform config |
| `/root/.hermes/.env` | API keys |
| `/root/.hermes/logs/gateway.log` | Gateway logs |
| `/root/.config/systemd/user/hermes-gateway.service` | Systemd unit |

---

## Commands Cheatsheet

```bash
hermes gateway status        # Check status
hermes gateway start/stop    # Control service
hermes gateway restart       # Restart
journalctl --user -u hermes-gateway -f  # Live logs
hermes whatsapp              # Re-pair (interactive)
hermes gateway setup         # Reconfigure platforms
```

---

## Notes for This Environment

- **SSH key**: `~/.ssh/vps_key` (not default `id_ed25519`)
- **SSH port**: 2222 (GreenCloud external firewall blocks 22)
- **VPS IP**: 194.127.192.52
- **aaPanel**: https://server.smartmillionaire.co.id:26676/a83a1c60
- **WordPress**: smartmillionaire.co.id/smart-webinar/ (Novamira MCP + smart-webinar plugin)
- **User prefers**: casual Indonesian, GUI over CLI, quick action ("gass")