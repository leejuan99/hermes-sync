---
name: vps-server-management
description: Class-level skill for managing VPS servers via aaPanel, GreenCloud, and SSH. Covers firewall configuration, SSH key management, Docker container management, and common troubleshooting patterns.
category: devops
tags: [vps, aapanel, greencloud, ssh, docker, firewall, ubuntu]
---

# VPS Server Management Skill

## Overview
Managing VPS servers (particularly GreenCloud VPS with aaPanel) including SSH access, firewall configuration, Docker management, and common troubleshooting.

## Trigger Conditions
- User needs to connect to VPS via SSH
- Firewall/port issues on VPS
- Docker container management on VPS
- aaPanel configuration tasks
- GreenCloud panel navigation

## Key Concepts

### GreenCloud External Firewall
**Critical:** GreenCloud has an **external firewall** that blocks ports even when UFW/aaPanel firewall allows them.
- Access: `https://greencloudvps.com/billing/login` → VPS → Network/Security/Firewall
- Must add rules there for SSH (22), HTTP (80), HTTPS (443), custom ports
- Port 22 often blocked by default

### aaPanel Firewall
- Access: aaPanel → Security → Firewall
- Add Port Rule: Protocol TCP, Port (22, 5678, etc.), Source 0.0.0.0/0, Action Allow
- Works alongside UFW (both must allow)

### SSH Key Management
```bash
# Generate key
ssh-keygen -t rsa -b 4096 -f ~/.ssh/vps_key

# Add public key to VPS
# Option 1: GreenCloud panel → SSH Keys → Add
# Option 2: aaPanel Terminal → echo "key" >> ~/.ssh/authorized_keys

# Test
ssh -i ~/.ssh/vps_key root@<VPS_IP> uptime
```

### Docker Container Management via aaPanel Terminal
```bash
# List containers
docker ps

# Pull latest image
docker pull n8nio/n8n:latest

# Recreate container with volume
docker stop n8n && docker rm n8n
docker run -d --name n8n -p 5678:5678 -v n8n_data:/home/node/.n8n n8nio/n8n:latest

# Check logs
docker logs n8n --tail 50
```

### Volume Data Recovery (Critical for n8n)
When n8n container recreated with new volume, old data in anonymous volume:
```bash
# Find old volume
docker volume ls

# Inspect volumes
docker volume inspect <old_volume> <new_volume>

# Copy data with permission fix
chown -R 1000:1000 /var/lib/docker/volumes/<new_volume>/_data
cp -r /var/lib/docker/volumes/<old_volume>/_data/* /var/lib/docker/volumes/<new_volume>/_data/
chown -R 1000:1000 /var/lib/docker/volumes/<new_volume>/_data
```

## Common Pitfalls

| Issue | Root Cause | Fix |
|-------|------------|-----|
| SSH timeout | GreenCloud external firewall blocks port 22 | Add rule in GreenCloud panel |
| SSH "Permission denied" | Key not in authorized_keys | Add key via GreenCloud panel or aaPanel Terminal |
| n8n "EACCES permission denied" | Volume owned by wrong UID | `chown -R 1000:1000 /var/lib/docker/volumes/...` |
| n8n user reset fails | Missing personal project in project table | Insert project row for user |
| Issue | Root Cause | Fix |
|-------|------------|-----|
| **Disk 99% full** | `/tmp` filled with `tirith-install-*` dirs (Novamira plugin bug), old WP backups in `ai1wm-backups`, aaPanel logs not rotated | Cleanup script + cron auto-cleanup (see below) |
| **aaPanel service "exited"** | bt.service shows "active (exited)" but webserver processes still running | `systemctl start bt` — service status misleading, processes alive |
| **aaPanel 404 on admin path** | **APSESS_PATH_RE middleware** blocks all URLs without `apsess_<token>` prefix. Pattern: `^/((?:apsess_)+[A-Za-z0-9]{16,32})(/.*|$)` blocks ALL URLs without token | **Fix:** Add admin path to exempt list in `require_apsess()` in `/www/server/panel/BTPanel/__init__.py`:\n```python\npublic_paths = (\n    '/login', '/v2/login', '/install', '/safe', '/hook', '/public',\n    '/down', '/userLang', '/google/redirect', '/google/callback',\n    '/a83a1c60/',  # ADD THIS\n    '/a83a1c60',   # AND THIS\n)\n``` |
| **Novamira tirith-install spam** | Plugin creates ~1500 dirs in `/tmp` (8.5MB each) daily | Cron cleanup + consider disabling Gutenberg ability if not used |
| **Novamira tirith-install spam** | Plugin creates ~1500 dirs in `/tmp` (8.5MB each) daily | Cron cleanup + consider disabling Gutenberg ability if not used |

## Workflow: SSH Setup from Scratch
1. Generate SSH key pair locally
2. Add public key to GreenCloud panel → SSH Keys
3. Restart VPS (GreenCloud panel)
4. Open port 22 in GreenCloud firewall
5. Open port 22 in aaPanel firewall
6. Test: `ssh -i ~/.ssh/vps_key root@<IP> uptime`

## Workflow: n8n Update & Recovery
1. `docker pull n8nio/n8n:latest`
2. `docker stop n8n && docker rm n8n`
3. `docker run -d --name n8n -p 5678:5678 -v n8n_data:/home/node/.n8n n8nio/n8n:latest`
4. If data missing: find old volume, copy data, fix permissions
5. If user auth broken: reset via `docker exec n8n n8n user-management:reset` (ensure project exists)

## Auto-Cleanup Cron (Prevent Disk 99%)
Add to root crontab (`crontab -e`):

```bash
# Auto cleanup tmp tirith-install daily (Novamira plugin bug)
0 3 * * * find /tmp -name "tirith-install-*" -type d -mtime +1 -exec rm -rf {} \; 2>/dev/null

# Clean old WP backups weekly (All-in-One WP Migration)
0 4 * * 0 find /www/wwwroot/*/wp-content/ai1wm-backups -type f -mtime +30 -delete 2>/dev/null

# Clean aaPanel logs monthly
0 5 1 * * find /www/server/panel/logs -name "*.log" -mtime +30 -delete 2>/dev/null
```

## Novamira tirith-install Cleanup (Disk 99% Root Cause)
**Root Cause:** Novamira Gutenberg plugin creates ~1500 directories in `/tmp` (8.5MB each) per run. Accumulates to 15GB+ quickly.

**Immediate Fix:**
```bash
rm -rf /tmp/tirith-install-*
```

**Prevention:**
1. Cron cleanup daily (above)
2. If Gutenberg ability not used, disable in Novamira admin panel
3. Check `/tmp` size weekly: `du -sh /tmp`

**Plugin Files Location:**
- Sandbox loader: `/www/wwwroot/smartmillionaire.co.id/wp-content/plugins/novamira/includes/sandbox-loader.php`
- Gutenberg bootstrap: `/wp-content/plugins/novamira/includes/abilities/gutenberg/bootstrap.php`

## References
- `references/aapanel-apsess-404-fix.md` - aaPanel 404 root cause (APSESS_PATH_RE middleware) and fix
- `references/greencloud-firewall.md` - GreenCloud firewall navigation
- `references/n8n-volume-recovery.md` - Detailed volume recovery steps
- `references/aapanel-firewall.md` - aaPanel firewall configuration
- `references/whatsapp-gateway-setup.md` - Hermes WhatsApp gateway (Baileys) setup on VPS

## Templates
- `templates/ssh-keygen.sh` - SSH key generation script
- `templates/n8n-docker-run.sh` - n8n container recreation script

## Scripts
- `scripts/check-ssh.sh` - Verify SSH connectivity
- `scripts/n8n-health-check.sh` - Check n8n container status