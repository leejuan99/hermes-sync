---
name: vps-server-admin
category: devops
version: 1.0
description: VPS Server Administration - aaPanel management, SSH hardening, 404/500 debugging
---

# VPS Server Administration - aaPanel Management

## Overview
Class-level skill for managing VPS servers, particularly aaPanel-based servers. Covers SSH access, aaPanel configuration, common issues (404, 500 errors), middleware troubleshooting, and SSH-based server management.

## Triggers
- User needs to manage VPS/aaPanel server
- aaPanel 404/500 errors
- SSH access issues
- aaPanel middleware/routing problems
- Server administration via SSH

## Core Knowledge

### aaPanel 404 Root Cause: APSESS Middleware
**Root Cause:** aaPanel has a middleware (`APSESS_PATH_RE`) that requires ALL URLs to have an `apsess_<token>/` prefix. URLs without this token return 404.

```python
# /www/server/panel/BTPanel/__init__.py line 59
APSESS_PATH_RE = re.compile(r"^/((?:apsess_)+[A-Za-z0-9]{16,32})(/.*|$)")
```

**Affected URLs:**
- `/a83a1c60/` → 404 (no apsess_ prefix)
- `/login` → 404 (blocked by middleware)
- `/apsess_<token>/a83a1c60/` → WORKS

### Solutions for aaPanel 404

#### Option 1: Access with Token (Immediate)
```bash
# Get token from panel logs or generate
# Format: https://domain:port/apsess_<token>/admin_path/
https://server.domain.com:26676/apsess_<token>/a83a1c60/
```

#### Option 2: Disable Middleware (Permanent)
```bash
# Edit /www/server/panel/BTPanel/__init__.py
# Comment out line ~216:
# wrap_apsess_middleware(app)
# →
# # wrap_apsess_middleware(app)
```

#### Option 3: Add Path to Whitelist
```bash
# Edit /www/server/panel/BTPanel/__init__.py
# In require_apsess() function, add to public_paths:
public_paths = (
    '/a83a1c60/',
    '/a83a1c60',
    '/v2/a83a1c60/',
    '/v2/a83a1c60',
    # ... existing paths
)
```

### Common aaPanel Issues & Fixes

| Issue | Fix |
|-------|-----|
| 404 on admin path | Add path to `require_apsess()` whitelist OR disable middleware |
| 500 Internal Server Error | Check `/www/server/panel/logs/error.log` |
| Login page not loading | Check middleware, SSL config, port 26676 |
| BT-Task fails to start | Check Python syntax in `/www/server/panel/class/public/common.py` |
| Panel won't restart | Check `init.sh` permissions, kill existing processes |

### SSH Hardening (Standard)
```bash
# Port 2222, key-only auth
Port 2222
PasswordAuthentication no
PubkeyAuthentication yes
PermitRootLogin prohibit-password
```

### UFW Firewall Rules
```bash
# Allow SSH (2222), HTTP/HTTPS, aaPanel (26676), n8n (5678)
ufw allow 2222/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw allow 26676/tcp
ufw allow 5678/tcp
# Deny MySQL external
ufw deny 3306
```

### Fix GetClientIp Syntax Error
```bash
# File: /www/server/panel/class/public/common.py
# Fix broken single-line function
def GetClientIp():
    from flask import request
    if request.remote_addr:
        ipaddr = request.remote_addr.replace("::ffff:", "")
        if not check_ip(ipaddr): return "Unknown IP address"
        return ipaddr
    return "Unknown IP address"
```

## SSH Access Patterns

### Standard Connection
```bash
ssh -p 2222 -i ~/.ssh/vps_key root@194.127.192.52
```

### Run Commands Remotely
```bash
# Single command
ssh -p 2222 -i ~/.ssh/vps_key root@194.127.192.52 "command"

# Multiple commands
ssh -p 2222 -i ~/.ssh/vps_key root@194.127.192.52 "
  cd /www/server/panel
  /www/server/panel/init.sh restart
"
```

### File Transfer
```bash
# Upload
scp -P 2222 -i ~/.ssh/vps_key local_file root@194.127.192.52:/remote/path

# Download
scp -P 2222 -i ~/.ssh/vps_key root@194.127.192.52:/remote/file ./local/
```

## Debugging Workflow

### 1. Check Panel Status
```bash
ps aux | grep -E 'BT-Panel|webserver'
ss -tlnp | grep 26676
```

### 2. Check Logs
```bash
# Panel error log
tail -50 /www/server/panel/logs/error.log

# Nginx/OpenLiteSpeed error log
tail -30 /www/server/panel/webserver/logs/error.log
```

### 3. Test Direct Socket
```bash
# Test panel socket directly
curl -k -s -o /dev/null -w '%{http_code}' --unix-socket /tmp/panel.sock http://localhost/a83a1c60/
```

### 4. Check Middleware Status
```bash
grep -n 'wrap_apsess_middleware' /www/server/panel/BTPanel/__init__.py
grep -n 'require_apsess' /www/server/panel/BTPanel/__init__.py
```

### 5. Restart Services
```bash
chmod +x /www/server/panel/init.sh
/www/server/panel/init.sh restart
```

## Pitfalls to Avoid

1. **Don't disable middleware without whitelist** - breaks panel access
2. **Always restart panel after config changes** - `init.sh restart`
3. **Check Python syntax before restart** - `python3 -m py_compile file.py`
4. **Clear Python cache after edits** - `find . -name '*.pyc' -delete && find . -name '__pycache__' -exec rm -rf {} +`
5. **Check panel socket exists** - `/tmp/panel.sock` must exist
5. **Verify nginx proxy config** - ensure `proxy_pass http://unix:/tmp/panel.sock;`

## Quick Reference Commands

```bash
# Full restart sequence
ssh -p 2222 -i ~/.ssh/vps_key root@194.127.192.52 "
  cd /www/server/panel
  /www/server/panel/init.sh restart
  sleep 5
  curl -k -s -o /dev/null -w '%{http_code}' https://localhost:26676/a83a1c60/
"

# Test panel locally
curl -k -s -o /dev/null -w '%{http_code}' https://localhost:26676/a83a1c60/
curl -k -s -o /dev/null -w '%{http_code}' https://localhost:26676/a83a1c60/login

# Test external access
curl -k -s -L -o /dev/null -w '%{http_code} -> %{redirect_url}' https://server.domain.com:26676/a83a1c60/

# Check panel logs for errors
ssh -p 2222 -i ~/.ssh/vps_key root@194.127.192.52 "tail -20 /www/server/panel/logs/error.log"
```

## Related Skills
- `github` - for version control of server configs
- `systematic-debugging` - for debugging methodology
- `terminal` - for SSH and command execution

## Version
1.0 - Initial creation based on aaPanel 404 debugging session