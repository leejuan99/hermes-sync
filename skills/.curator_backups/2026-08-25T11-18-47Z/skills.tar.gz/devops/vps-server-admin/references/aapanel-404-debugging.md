# aaPanel 404 Debugging Session - Detailed Reference

## Session Overview
**Date:** 2026-07-03 to 2026-07-04
**Issue:** aaPanel returning 404 on admin path `/a83a1c60/`
**Root Cause:** APSESS_PATH_RE middleware requiring `apsess_<token>/` prefix

## Root Cause Analysis

### The Middleware
```python
# /www/server/panel/BTPanel/__init__.py line 59
APSESS_PATH_RE = re.compile(r"^/((?:apsess_)+[A-Za-z0-9]{16,32})(/.*|$)")
```

This middleware wraps the Flask app via:
```python
wrap_apsess_middleware(app)  # Line 216
```

### Middleware Logic (`ApsessPathMiddleware`)
1. Extracts token from URL path: `/apsess_<token>/<real_path>`
2. Sets `environ['bt.apsess_token']` and rewrites `PATH_INFO`
3. If NO token found → sets empty token but **continues to app** (allows through)
4. BUT `check_apsess_path()` in `@app.before_request` **blocks** requests without valid token

### The `require_apsess()` Function
Determines which paths need apsess validation:
```python
def require_apsess():
    # Exempt paths:
    fixed_entry_paths = {'/', admin_path, route_path}
    if normalized_path in fixed_entry_paths:
        return False
    
    if is_safe_static_route_request():
        return False
    
    if is_plugin_api_exempt_request():
        return False
    
    # Public paths exempt:
    public_paths = (
        '/login', '/v2/login', '/install', '/safe', '/hook', '/public',
        '/down', '/userLang', '/google/redirect', '/google/callback'
    )
    for p in public_paths:
        if request.path == p or request.path.startswith(p):
            return False
    
    # Authenticated users: FORCE apsess validation
    return session.get('login', False)
```

**Critical Issue:** `/a83a1c60/` is NOT in `fixed_entry_paths` (it's `route_path` but with trailing slash mismatch) and NOT in `public_paths`.

### The Middleware Chain
1. Request comes in: `/a83a1c60/`
2. `ApsessPathMiddleware` - no token found → sets empty token, continues to app
3. `request_check()` runs → calls `check_apsess_path()`
3. `check_apsess_path()` → no token in environ → calls `handle_invalid_apsess()`
4. `handle_invalid_apsess()` → `require_apsess()` returns `True` (user logged in)
5. `handle_invalid_apsess()` → returns `abort(403)` → nginx shows 404

### Why Login Works Sometimes
The `/login` path IS in `public_paths` exempt list, so `require_apsess()` returns `False` for it.

## Fixes Applied

### 1. Fixed GetClientIp Syntax Error
**File:** `/www/server/panel/class/public/common.py` line 1113
**Issue:** Broken single-line function causing SyntaxError
**Fix:** Proper multi-line function with proper indentation

### 2. Re-enabled Middleware + Whitelist
```python
# Re-enable middleware
wrap_apsess_middleware(app)

# Add to public_paths in require_apsess():
public_paths = (
    '/a83a1c60/',
    '/a83a1c60',
    '/v2/a83a1c60/',
    '/v2/a83a1c60',
    # ... existing paths
)
```

### 3. Fixed GetClientIp Syntax Error
```python
def GetClientIp():
    from flask import request
    if request.remote_addr:
        ipaddr = request.remote_addr.replace("::ffff:", "")
        if not check_ip(ipaddr): return "Unknown IP address"
        return ipaddr
    return "Unknown IP address"
```

## Testing Commands
```bash
# Test panel locally
curl -k -s -o /dev/null -w '%{http_code}' https://localhost:26676/a83a1c60/

# Test with token
curl -k -s -o /dev/null -w '%{http_code}' https://localhost:26676/apsess_<token>/a83a1c60/

# Check panel status
ps aux | grep -E 'BT-Panel|webserver'
ss -tlnp | grep 26676
```

## Key Files Modified
1. `/www/server/panel/class/public/common.py` - Fixed GetClientIp
2. `/www/server/panel/BTPanel/__init__.py` - Re-enabled middleware, added whitelist paths

## Lessons Learned
1. **Always check middleware first** when seeing 404 on valid routes
2. **Check require_apsess() whitelist** for custom admin paths
3. **Test with Flask test client** to isolate middleware vs routing issues
4. **Check panel error logs** for AttributeError/500 errors
5. **Middleware wraps WSGI app** - affects all requests before Flask routing