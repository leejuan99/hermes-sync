# 9Router Deployment on VPS

## Docker Container Setup
```bash
# Pull image
docker pull decolua/9router:latest

# Run with custom API key secret and persistent data
docker run -d --name 9router --restart unless-stopped \
  -p 20128:20128 \
  -e INITIAL_PASSWORD=your_password \
  -e API_KEY_SECRET=your_custom_secret \
  -v /root/9router-data:/app/data \
  decolua/9router:latest
```

## API Key Generation (Critical)
9Router stores keys in SQLite (`/root/9router-data/db/data.sqlite`). Dashboard API returns truncated keys. Get full key:
```bash
# 1. Login and create key via API
curl -c cookies.txt -X POST http://localhost:20128/api/auth/login \
  -H 'Content-Type: application/json' -d '{"password":"your_password"}'
curl -b cookies.txt -X POST http://localhost:20128/api/keys \
  -H 'Content-Type: application/json' -d '{"name":"hermes"}'

# 2. Full key only visible ONCE in response - copy immediately
# 3. Or query DB directly:
sqlite3 /root/9router-data/db/data.sqlite 'SELECT key FROM apiKeys WHERE name="hermes"'
```

## Connect Free Providers (Dashboard → Providers)
- **Kiro AI**: ~50 credits/month (Claude 4.5, GLM-5, MiniMax)
- **OpenCode Free**: No auth required
- **Vertex AI**: $300 free credits (Gemini models)

## Hermes Config for 9Router
```bash
hermes config set model.base_url "http://9router.smartmillionaire.co.id/v1"
hermes config set model.api_key "sk-xxx...full_key"
hermes config set model.default "kr/claude-sonnet-4.5"
hermes gateway restart
```