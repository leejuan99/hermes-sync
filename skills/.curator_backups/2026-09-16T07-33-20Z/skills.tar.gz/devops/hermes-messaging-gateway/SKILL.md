---
name: hermes-messaging-gateway
description: "Use when setting up or fixing Hermes chat gateway."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [hermes, gateway, whatsapp, telegram, messaging, troubleshooting]
---

# Hermes Messaging Gateway

Connect and debug Hermes gateway chat platforms from the desktop app.

## Setup procedure

1. Run the platform wizard first, then the gateway:
   `hermes gateway setup` (pick platform) or `hermes whatsapp` for WhatsApp QR pairing.
2. Scan the QR via WhatsApp > Settings > Linked Devices > Link a Device.
3. Wait for `Pairing complete. Credentials saved`, then start `hermes gateway run` and leave it running.
4. Test by messaging the bot number from a second phone; expect an agent reply.
5. For always-on, use `hermes gateway install` then `hermes gateway start`.

## Verify state before guessing

- Check `gateway_state.json` (`platforms.whatsapp.state`) for `connected` vs error before touching config.
- Check `whatsapp/bridge.log` for `Bridge ready (status: connected)` and per-message `event` lines.
- Telegram `polling conflict` and `API_SERVER_KEY required` errors do not block WhatsApp; ignore them when only WhatsApp matters.
- Never run Linux panel commands (aaPanel paths) inside Windows PowerShell; they always fail with CommandNotFound.
- One active gateway per WhatsApp session: check for an already-running `gateway run`
  process before starting another; duplicates cause Telegram polling conflicts and
  WhatsApp session fights.
- Start long-lived gateway processes silent (no broad `error` notify patterns) and kill
  stale watchers; otherwise notification spam drowns real signals.

## VPS migration (24/7 bot)

- Full procedure: `references/vps-migration.md` — version match, secret transfer without
  displaying values, session copy to skip re-pairing, source-first cutover order,
  service install, skills/memory/MCP port.

## WhatsApp allowlist (no-reply root cause)

- An empty `WHATSAPP_ALLOWED_USERS` denies everyone by design; `*` opens the bot explicitly.
- Diagnose no-reply with bridge.log `ignored / allowlist_mismatch` plus sender in LID form (`NNNN@lid`).
- Resolve the sender LID to its phone via session file `lid-mapping-<LID>_reverse.json`, then add phone AND LID to `WHATSAPP_ALLOWED_USERS` (comma-separated in `.env`).
- WhatsApp increasingly addresses senders by LID, so an allowlist holding only the bot's own phone number silently drops real users; always include the actual sender identities.
- Restart the gateway after changing the allowlist; the bridge reads it once at startup.

## Desktop terminal assist

- When the user says the terminal shows nothing, force visibility with `terminal-deck` layout, then inspect with `read_terminal` (page with start_line/count for scrollback) instead of asking what they see.
- When the shell shows a continuation prompt (`>>` in PowerShell), tell them to cancel with Ctrl+C and re-enter the command cleanly.
- Answer "what do I type here" from the actual visible prompt (e.g. allowlist phone prompt takes comma-separated international numbers), not from generic docs.
